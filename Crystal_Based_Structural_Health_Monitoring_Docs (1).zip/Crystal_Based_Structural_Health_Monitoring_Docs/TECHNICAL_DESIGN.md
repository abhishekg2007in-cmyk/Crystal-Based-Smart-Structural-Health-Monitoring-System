# Technical Design Document
## Crystal-Based Smart Structural Health Monitoring System

### 1. Purpose
Describe a prototype architecture that uses piezoelectric sensing to observe vibration or mechanical changes and flag readings for engineering review.

### 2. Scope
Included in this documentation:
- Sensor-to-microcontroller data flow.
- Example threshold-based alert logic.
- Sample CSV format and basic validation tests.

Not implemented in the sample software:
- Real sensor drivers or hardware calibration.
- Live wireless transmission.
- A production dashboard, authentication service, or notification delivery.
- Certified structural-health diagnosis.

### 3. Architecture diagram

```mermaid
flowchart LR
    A[Structure / test model] --> B[Piezoelectric sensor]
    B --> C[Signal conditioning]
    C --> D[Microcontroller]
    D --> E[Feature extraction and threshold check]
    E --> F{Reading exceeds configured threshold?}
    F -- No --> G[Record normal reading]
    F -- Yes --> H[Create warning event]
    G --> I[Wireless link - planned]
    H --> I
    I --> J[Dashboard / data store - planned]
    J --> K[Engineer reviews data and arranges inspection]
```

**Legend:** The sensing and processing path is the proposed design. Wireless transmission and dashboard are planned components unless separately built and tested.

### 4. Main components

| Component | Responsibility | Notes |
|---|---|---|
| Piezoelectric sensor | Converts mechanical strain/vibration into an electrical signal | Sensor type and placement require engineering selection |
| Signal conditioning | Filters/amplifies signal for acquisition | Must match sensor output and microcontroller input |
| Microcontroller | Samples and processes signal | Example platform: ESP32; final choice depends on requirements |
| Detection logic | Calculates a feature and checks configured threshold | Thresholds require calibration and validation |
| Wireless communication | Transfers readings and warnings | Planned; secure transport and reconnect behavior needed |
| Dashboard/data store | Displays trends and alert history | Planned; access control and retention policy needed |

### 5. Data flow
1. The sensor responds to vibration or mechanical changes.
2. The signal-conditioning stage prepares the signal for acquisition.
3. The microcontroller samples the signal and computes a reading or feature.
4. Detection logic compares the feature with a configured threshold.
5. The system logs the reading and flags threshold exceedances.
6. If connected components are implemented, readings can be sent to a dashboard.
7. A qualified engineer reviews alerts and decides whether further inspection is required.

### 6. Sample data format
CSV fields:
- `timestamp`: ISO-like date/time for the sample.
- `device_id`: sensor-node identifier.
- `reading`: numeric demonstration value.
- `unit`: unit or feature name used by the prototype.
- `threshold`: configured illustrative threshold.
- `status`: `NORMAL` or `ALERT`.

The example dataset uses arbitrary demo units. Do not interpret it as an engineering limit.

### 7. Alert logic (demonstration only)
A reading is flagged `ALERT` if its numeric value is greater than the configured threshold; otherwise it is `NORMAL`. Production logic should include calibration, filtering, noise handling, sensor-fault detection, baseline/trend analysis, and engineer-approved thresholds.

### 8. Reliability, security, and safety
- Use stable sensor mounting and document calibration.
- Detect missing, stale, saturated, or disconnected sensor readings.
- Keep a timestamped log of readings and configuration changes.
- Protect any dashboard endpoint with authentication and encrypted transport.
- Store credentials in environment variables or a secret manager, not source control.
- Define alert escalation and maintenance procedures.
- Have qualified structural engineers validate all thresholds and interpretations.
- Never treat a single threshold alert as a definitive structural diagnosis.

### 9. Verification plan
- Unit-test CSV fields and numeric values.
- Test values below, equal to, and above the demonstration threshold.
- Test missing and malformed values.
- In hardware trials, compare sensor output against a suitable reference instrument and document calibration, repeatability, and environmental effects.
