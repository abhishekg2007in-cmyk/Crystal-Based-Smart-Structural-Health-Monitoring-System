# Crystal-Based Smart Structural Health Monitoring System

## Overview
A prototype concept for monitoring structural changes using piezoelectric sensors, a microcontroller, and wireless data transmission. The system collects sensor readings, identifies readings that cross configured thresholds, and presents warnings for review by a responsible engineer.

> **Safety note:** This is a prototype/project concept, not a certified structural-safety system. Sensor readings and threshold alerts must not be used as the sole basis for declaring a building, bridge, or dam safe or unsafe. Real deployments require engineering validation, calibration, redundancy, and professional inspection.

## Main features
- Collects vibration or sensor-signal readings.
- Applies configurable thresholds to flag unusual readings.
- Sends readings to a monitoring dashboard over a wireless connection (when implemented).
- Records sample readings and alert events for review.

## Suggested prototype architecture
1. Piezoelectric sensor(s) mounted on a test structure/model.
2. Signal-conditioning circuit and microcontroller.
3. Local processing to calculate a reading or feature.
4. Wi-Fi/Bluetooth or another approved communication link.
5. Dashboard or logging service for readings and alerts.

## Requirements
- Python 3.10+ for the optional sample-data validator.
- A microcontroller and compatible sensor hardware for physical prototyping.
- A dashboard/backend if remote viewing is implemented.

## Setup (sample-data validator)
1. Install Python 3.10 or newer.
2. Unzip the project folder.
3. Open a terminal in this folder.
4. Run:
   ```bash
   python -m venv .venv
   ```
5. Activate the environment:
   - Windows PowerShell: `.venv\\Scripts\\Activate.ps1`
   - macOS/Linux: `source .venv/bin/activate`
6. Install the optional test dependency:
   ```bash
   python -m pip install -r requirements.txt
   ```
7. Validate the included sample data:
   ```bash
   python validate_sample_data.py
   ```
8. Run tests:
   ```bash
   python -m unittest discover -s tests -v
   ```

## Environment variables
The sample validator does not require environment variables. A future connected implementation may use:

| Variable | Purpose | Example |
|---|---|---|
| `MONITORING_MODE` | `demo` or `hardware` operating mode | `demo` |
| `ALERT_THRESHOLD` | Demonstration threshold in the chosen reading unit | `2.5` |
| `DEVICE_ID` | Identifier for the sensor node | `demo-node-01` |
| `DASHBOARD_ENDPOINT` | Optional endpoint for a future dashboard/API | `https://example.invalid/api/readings` |
| `API_TOKEN` | Optional secret for an authenticated endpoint | Set privately; never commit real tokens |

Set these variables only if the connected implementation supports them. Example for PowerShell:
```powershell
$env:MONITORING_MODE="demo"
$env:ALERT_THRESHOLD="2.5"
$env:DEVICE_ID="demo-node-01"
```

## Project structure
```text
.
├── README.md
├── TECHNICAL_DESIGN.md
├── LICENSE
├── requirements.txt
├── sample_data/
│   └── sensor_readings.csv
├── validate_sample_data.py
└── tests/
    └── test_validator.py
```

## Limitations
- The included readings are synthetic demonstration data, not measurements from real structures.
- The threshold is illustrative and must be calibrated for each sensor, structure, and installation.
- The software currently validates sample data only; it does not connect to real hardware or provide a production dashboard.
