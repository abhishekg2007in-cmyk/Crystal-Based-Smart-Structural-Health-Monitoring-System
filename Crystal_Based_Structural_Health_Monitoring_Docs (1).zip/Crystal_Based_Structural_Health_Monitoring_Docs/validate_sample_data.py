import csv
from pathlib import Path

DATA_FILE = Path(__file__).parent / "sample_data" / "sensor_readings.csv"
REQUIRED_FIELDS = {"timestamp", "device_id", "reading", "unit", "threshold", "status"}


def validate_rows(path=DATA_FILE):
    """Validate sample CSV structure and demonstration threshold statuses."""
    with open(path, newline="", encoding="utf-8") as csvfile:
        reader = csv.DictReader(csvfile)
        if not reader.fieldnames or not REQUIRED_FIELDS.issubset(reader.fieldnames):
            raise ValueError(f"CSV must include fields: {sorted(REQUIRED_FIELDS)}")

        rows = list(reader)
        if not rows:
            raise ValueError("CSV contains no readings")

        for line_number, row in enumerate(rows, start=2):
            try:
                reading = float(row["reading"])
                threshold = float(row["threshold"])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Invalid numeric reading/threshold on line {line_number}") from exc

            expected = "ALERT" if reading > threshold else "NORMAL"
            if row["status"].strip().upper() != expected:
                raise ValueError(
                    f"Status mismatch on line {line_number}: expected {expected}"
                )
            if not row["timestamp"].strip() or not row["device_id"].strip():
                raise ValueError(f"Missing timestamp or device_id on line {line_number}")

        return len(rows)


if __name__ == "__main__":
    count = validate_rows()
    print(f"Sample data valid: {count} readings checked.")
