import csv
import tempfile
import unittest
from pathlib import Path

from validate_sample_data import validate_rows


class ValidatorTests(unittest.TestCase):
    def test_included_sample_data_is_valid(self):
        self.assertEqual(validate_rows(), 5)

    def test_alert_above_threshold(self):
        content = (
            "timestamp,device_id,reading,unit,threshold,status\n"
            "2026-10-20T09:00:00,node-1,3.0,demo_units,2.5,ALERT\n"
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "sample.csv"
            path.write_text(content, encoding="utf-8")
            self.assertEqual(validate_rows(path), 1)

    def test_mismatched_status_fails(self):
        content = (
            "timestamp,device_id,reading,unit,threshold,status\n"
            "2026-10-20T09:00:00,node-1,3.0,demo_units,2.5,NORMAL\n"
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "sample.csv"
            path.write_text(content, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Status mismatch"):
                validate_rows(path)

    def test_invalid_number_fails(self):
        content = (
            "timestamp,device_id,reading,unit,threshold,status\n"
            "2026-10-20T09:00:00,node-1,unknown,demo_units,2.5,NORMAL\n"
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "sample.csv"
            path.write_text(content, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Invalid numeric"):
                validate_rows(path)


if __name__ == "__main__":
    unittest.main()
